package arquivo_serializacao;

import java.io.*;
import java.lang.Exception;
import java.util.ArrayList;
import java.util.Collections;


public class LeituraArquivos implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String nomeArquivo = "";
	private ArrayList<Compras> historico;
	private ArrayList<Compras> relatorio;

	
	public LeituraArquivos(String nomeArquivo) {
		this.nomeArquivo = nomeArquivo;
		historico = new ArrayList<Compras>();
		relatorio = new ArrayList<Compras>();
	}
	
	public void LerTXT(){
		 try {
	            BufferedReader arq = new BufferedReader(new FileReader(nomeArquivo));
	            String linha = arq.readLine();

	            while (linha != null) {
	                String[] campos = linha.split(",");
	                addLista(new Compras(campos[0], campos[1], campos[2], Double.parseDouble(campos[3])));
	                linha = arq.readLine();
	            }
	            arq.close();
	     } 
		 catch (FileNotFoundException e) {
	            System.out.println("Impossível abrir o arquivo: " + nomeArquivo);

	     } 
		 catch (IOException e) {
	            System.out.println("Problema na leitura do arquivo");
	     }
	}
	
	public void gravarRelatorioTxt() {
		String cpf = relatorio.get(0).getCPF();
		
		try (FileWriter arquivo = new FileWriter(cpf + ".txt")) {
            for (Compras compras : relatorio) {
                arquivo.write(compras.getCPF() + "," + compras.getNome() + "," + compras.getData() + "," + compras.getValor() + "\n");
            }
        }
		catch (IOException e) {
            System.out.println("Falha ao salvar o Arquivo " + cpf + ".txt");
        }
	}
	
	public void gerarRelatorio(String cpf) {
		Compras cliente = new Compras();
		relatorio = cliente.gerarRelatorioCliente(historico, cpf);
	}
	
	public void lerBIN(String nomeArquivo) {
		ManipuladoraArquivos arqBin = new ManipuladoraArquivos();
		Compras compras = new Compras();
		compras = arqBin.lerArquivoBinario(nomeArquivo);
	}
	
	public void addLista(Compras compra) {
		historico.add(compra);
	}
}
