package arquivo_serializacao;

import java.io.IOException;
import java.util.Scanner;


public class Principal {

	private static String arquivoTxt = "dadosTexto.txt";
	private static String arquivoBin = "dadosBinario.bin";
	private static Scanner in = new Scanner(System.in);
	private static LeituraArquivos arqTxt = new LeituraArquivos(arquivoTxt);
	
	public static void main(String[] args) throws IOException{

		int opcao = 0;
		
		String cpf = "";
		
		do {
			
			menu();
			opcao = in.nextInt();
			switch(opcao) {
				case 1:
					arqTxt.LerTXT();
					break;
					
				case 2:
					arqTxt.lerBIN(arquivoBin);
					break;
					
				case 3:
					System.out.print("CPF ");
					cpf = in.next();
					arqTxt.gerarRelatorio(cpf);
					
				case 4:
					arqTxt.gravarRelatorioTxt();
					break;
					
				case 5:
					break;
			}
			
		}while(opcao != 6);
	}
	
	public static void menu() {
		System.out.print(
			"1 - Carregar dados de arquivo texto; \n"
			+ "2 - Carregar dados de arquivo binario; \n"
			+ "3 - Gerar relatorio na tela; \n"
			+ "4 - Salvar relatorio em arquivo de texto \n"
			+ "5 - Sair. \n\n"
		);
	}

}
