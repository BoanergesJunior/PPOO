package arquivo_serializacao;

import java.io.*;

public class ManipuladoraArquivos {

    public Compras lerArquivoBinario(String nomeArq) {
    	Compras arq = null;
    	
        try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nomeArq))) {
        	arq = (Compras) ois.readObject();
        } 
        catch(Exception e) {
            System.out.println(e.getMessage() + " deu erro");
        }

        return arq;
    }	
}
