//package padrao_strategy;

public interface NotaFiscal {
	public double calcularNota();
}
